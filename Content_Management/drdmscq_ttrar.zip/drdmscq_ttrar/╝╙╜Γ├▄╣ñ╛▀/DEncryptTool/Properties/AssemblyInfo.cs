﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// 有关程序集的常规信息通过下列属性集
// 控制。更改这些属性值可修改
// 与程序集关联的信息。
[assembly: AssemblyTitle("动软加密/解密工具")]
[assembly: AssemblyProduct("动软加密/解密工具")]
[assembly: AssemblyDescription("20110412")]
[assembly: AssemblyVersion("2.00")]
[assembly: AssemblyFileVersion("2.00")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("动软卓越（北京）科技有限公司")]
[assembly: AssemblyCopyright("Copyright(C)2004-2011 Maticsoft All Rights Reserved.")]
//[assembly: AssemblyCopyright("版权所有 (C) Maticsoft 2004-2011")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// 将 ComVisible 设置为 false 使此程序集中的类型
// 对 COM 组件不可见。如果需要从 COM 访问此程序集中的类型，
// 则将该类型上的 ComVisible 属性设置为 true。
[assembly: ComVisible(false)]

// 如果此项目向 COM 公开，则下列 GUID 用于类型库的 ID
[assembly: Guid("46292218-3b4b-4e1b-ade6-7d3fa247ccfd")]


